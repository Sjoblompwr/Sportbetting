/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author David Sjöblom
 */
public class AddNewTeamServiceIT {

    /**
     * Test of execute method, of class AddNewTeamService.
     * IT with ServiceRunner
     */
    @Test
    public void testExecute() {
        System.out.println("AddNewTeam IT");
        AddNewTeamService service = null;
        int sport_id = 1;
        int season_id = 1;
        int league_id = 1;
        String name = "Pelikans";
        try{
            service = new AddNewTeamService(sport_id, season_id, league_id, name);
        }catch(Exception e){
            fail(e + "Big chance of the team already existing, recommend appending"
                    + "current team name to check if test working.");
        }
        ServiceRunner<Boolean> serviceRunner = new ServiceRunner(service);
        Boolean result = serviceRunner.execute();
        assertTrue(result,"If fail, the team might already exist, try with new name"
                + "before assuming the method is not working.");
    }
}
