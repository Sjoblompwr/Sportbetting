/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author David Sjöblom
 */
public class AddNewSportServiceIT {
  

    /**
     * Test of execute method, of class AddNewSportService.
     * IT with ServiceRunner
     */
    @Test
    public void testExecute() {
        System.out.println("AddNewSport IT");
        String name = "Dota";
        AddNewSportService service = null;
        try{
            service = new AddNewSportService(name);
        }catch(Exception e){
            fail(e + "Sport might already exist.");
        }
        ServiceRunner<Boolean> serviceRunner = new ServiceRunner(service);
        Boolean result = serviceRunner.execute();
        assertTrue(result,"Sport might already exist.");
    }
    
}
