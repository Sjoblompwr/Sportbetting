/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author David Sjöblom
 */
public class AddNewLeagueForSeasonServiceIT {
   

    /**
     * Test of execute method, of class AddNewLeagueForSeasonService.
     * IT with ServiceRunner
     */
    @Test
    public void testExecute() {
        System.out.println("AddNewLeagueForSeason IT");
        AddNewLeagueForSeasonService service = null;
        int id = 1;
        String name = "Korpen";
        try{
            service = new AddNewLeagueForSeasonService(id, name);
        }catch(Exception e){
            fail(e + "League might already exist.");
        }
        ServiceRunner<Boolean> serviceRunner = new ServiceRunner(service);
        Boolean result = serviceRunner.execute();
        assertTrue(result,"League might already exist, try changing to new league name");
    }
    
}
