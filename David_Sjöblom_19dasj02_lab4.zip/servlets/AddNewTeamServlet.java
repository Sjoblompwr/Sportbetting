/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import service.AddNewTeamService;
import service.ServiceRunner;

/**
 *
 * @author David Sjöblom
 */
public class AddNewTeamServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int sport_id,season_id,league_id;
        String name;
        Exception ex = null;
        boolean newTeamBool;
        
        sport_id = Integer.valueOf(request.getParameter("sport_id"));
        season_id = Integer.valueOf(request.getParameter("season_id"));
        league_id = Integer.valueOf(request.getParameter("league_id"));
        name = request.getParameter("name");
        
        AddNewTeamService service = null;
        try{
            service = new AddNewTeamService(sport_id,season_id,league_id,name);   
        }catch(Exception e){
            newTeamBool = false;
            ex = e;
        }
        ServiceRunner<Boolean> serviceRunner = new ServiceRunner(service);
        try{
            newTeamBool = serviceRunner.execute();
        }catch(Exception e){
            ex = e;
            newTeamBool = false;
        }
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            if(newTeamBool){
                out.println("New team created.");
            }
            else{
                out.println(ex + " New team already exist.(or one of the ids are"
                        + " wrong and I haven't coded it all out (: ).");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
